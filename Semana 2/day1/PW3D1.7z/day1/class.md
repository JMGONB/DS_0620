1. Python_IX_Precurse
    - map/filter, reduce (itertools)
2. https://www.practicepython.org/
3. exercises/dictionary_exercise-9
4. exercises/flota/exercises_hundir_flota

---------

*Remember, you have many cheatsheets. Learn to use it.*

*PythonTutor is your friend... take care of it.*

*Use Google everytime you need. Google must be your shadow.*

---------

**Lead Instructor**: *Gabriel Vázquez Torres*

- gabriel@thebridgeschool.es

**Teacher Assistant**: *Clara Piniella Martinez*

- clara.piniella@thebridgeschool.es